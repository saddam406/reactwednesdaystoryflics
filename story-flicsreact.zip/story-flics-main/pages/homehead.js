import React from 'react'
import Homehead from "../HomeComponents/Homehead"

function homehead() {
  return (
    <div>
    <Homehead/>
    </div>
  )
}

export default homehead