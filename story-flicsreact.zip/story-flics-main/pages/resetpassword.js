import React from 'react'
import Resetpassword from '../Signiocomponent/Resetpassword'

function resetpassword() {
  return (
    <div><Resetpassword/></div>
  )
}

export default resetpassword