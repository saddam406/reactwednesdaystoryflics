import React from 'react'
import Codeupload from '../UploadComponent/Codeupload'


function upload() {
  return (
    <div>
        <Codeupload/>
    </div>
  )
}

export default upload