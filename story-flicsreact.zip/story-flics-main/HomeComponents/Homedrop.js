// import React from "react";
// import "antd/dist/antd.css";
// import { Menu, Dropdown, Space } from "antd";
// import { DownOutlined } from "@ant-design/icons";

// const { SubMenu } = Menu;

// const menu = (
//   <Menu
//     items={[
//       {
//         type: "group",
//         label: "Language",
//         children: [
//           {
//             key: "1",
//             label: "English"
//           },
//           {
//             key: "2",
//             label: "Tamil"
//           },
//           {
//             key: "3",
//             label: "Telugu"
//           },
//           {
//             key: "4",
//             label: "Hindi"
//           },
//           {
//             key: "5",
//             label: "Malayalam"
//           },
//           {
//             key: "6",
//             label: "Spanish"
//           },
//           {
//             key: "7",
//             label: "German"
//           },
//           {
//             key: "8",
//             label: "Chinese"
//           },
//           {
//             key: "9",
//             label: "Arabic"
//           },
//           {
//             key: "10",
//             label: "Japanese"
//           }
//         ]
//       },
//       {
//         key: "sub",
//         label: "Genres",
//         children: [
//           {
//             key: "11",
//             label: "Comedy"
//           },
//           {
//             key: "12",
//             label: "Fantacy"
//           },
//           {
//             key: "13",
//             label: "Horror"
//           },
//           {
//             key: "14",
//             label: "Action"
//           },
//           {
//             key: "15",
//             label: "Mystery"
//           },
//           {
//             key: "16",
//             label: "Adventure"
//           },
//           {
//             key: "17",
//             label: "Romance"
//           },
//           {
//             key: "18",
//             label: "General Fiction"
//           },
//           {
//             key: "19",
//             label: "Thriller"
//           },
//           {
//             key: "20",
//             label: "Biography"
//           },
//           {
//             key: "21",
//             label: "Business"
//           },
//           {
//             key: "23",
//             label: "Mythology"
//           },
//           {
//             key: "24",
//             label: "Life style"
//           },
//           {
//             key: "25",
//             label: "Inspiration"
//           }
//         ]
//       },
//       {
//         label: "Age",
//         key: "26",
//         children: [
//           {
//             key: "27",
//             label: "Kids(5 - 12)"
//           },
//           {
//             key: "28",
//             label: "Teens(13 - 17)"
//           },
//           {
//             key: "29",
//             label: "Adult(18+)"
//           }
//         ]
//       }
//     ]}
//   />
// );

// export default Homedrop = () => (
//   <Dropdown overlay={menu}>
//     <a onClick={(e) => e.preventDefault()}>
//       <Space>
//         Browse Categorizes
//         <DownOutlined />
//       </Space>
//     </a>
//   </Dropdown>
// );
