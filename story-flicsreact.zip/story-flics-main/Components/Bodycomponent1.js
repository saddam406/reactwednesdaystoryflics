import React from 'react'

function Bodycomponent1() {
  return (
    <div style={{width:'100%',height:'445px',background:'#e7e7e7',marginTop:'-37px',}}>
        <ul style={{display:'flex',marginLeft:'35px',listStyleType:'none'}}><li>
            <div style={{width:'650px',height:'100%',marginTop:'70px'}}>
                <ul style={{listStyleType:'none'}}>
                    <li><img width="150px" src='https://github.com/vijay9655/Sample-img/blob/main/Group%2015.png?raw=true'/>&nbsp;&nbsp; &nbsp;&nbsp;    <img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Group%203.png?raw=true"/>&nbsp;&nbsp; &nbsp;&nbsp;  <img width="150px" src='https://github.com/vijay9655/Sample-img/blob/main/Group%2016.png?raw=true'/>   </li>
                    <li style={{marginTop:'30px'}}><img width="150px" src='https://github.com/vijay9655/Sample-img/blob/main/Group%2018.png?raw=true'/>&nbsp;&nbsp; &nbsp;&nbsp;    <img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Group%2017.png?raw=true"/>&nbsp;&nbsp; &nbsp;&nbsp; <img width="150px" src='https://github.com/vijay9655/Sample-img/blob/main/Group%201.png?raw=true'/></li>
                    


                </ul>

            </div></li>
            <li>
                <div style={{color:"#31466e"}}>
                <p style={{fontSize:'45px',fontFamily:'poppins',marginTop:'70px'}}><b>Genres</b></p>
                <p style={{marginTop:'-30px',fontFamily:'poppins',fontSize:'28px',}}><b>Your favourite genres in one place</b></p>
                <p style={{fontSize:'29px',fontFamily:'poppins',marginTop:'-25px'}}>Storyflics aspires users to search and
find<br/> stories from all favourite genres in
one place<br/>around the world.Enjoy 
watching stories under<br/>specific age
group of your choice.</p>
                </div>
            </li>
        </ul>
    </div>
  )
}

export default Bodycomponent1