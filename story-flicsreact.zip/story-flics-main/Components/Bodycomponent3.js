import React from 'react'

function Bodycomponent3() {
  return (
    <div style={{width:'100%',height:'450px',background:'#e7e7e7',display:'inline-block',color:'#31466e',textAlign:'center'}}>
    <p style={{fontSize:'37px',marginTop:'30px',fontFamily:'poppins'}}><b>Everyone has a story.We can help you tell yours</b></p>
    <p style={{textAlign:'center',marginTop:'-40px'}}><img width="300px" src='https://github.com/vijay9655/Sample-img/blob/main/narrate-01.png?raw=true'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img width="300px" src='https://github.com/vijay9655/Sample-img/blob/main/record-01.png?raw=true'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img width="300px" src='https://github.com/vijay9655/Sample-img/blob/main/upload-01.png?raw=true'/></p>
    <ul style={{display:'flex',fontFamily:'poppins',fontSize:'25px',marginTop:'-40px',listStyleType:'none'}}>
        <li style={{marginLeft:'100px'}}><b>Narrate your Story</b></li>
        <li style={{marginLeft:'230px'}}><b>Record your Story</b></li>
        <li style={{marginLeft:'250px'}}><b>Upload your Story</b></li>

    </ul>
    </div>

  )
}

export default Bodycomponent3