export const Signin_DATA = "Signin_DATA";
export const Signup_DATA = "signup_DATA";
export const Signindata_DATA = "signindata_DATA";
export const Verify_DATA = "Verify_DATA";
export const Password_DATA = "Password_DATA";
export const DELETE_DATA="DELETE_DATA";

// export const DELETE_DATA = "DELETE_DATA";
// export const EDIT_DATA = "EDIT_DATA";