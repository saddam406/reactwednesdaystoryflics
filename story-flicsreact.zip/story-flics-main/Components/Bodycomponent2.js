import React from 'react'

function Bodycomponent2() {
  return (
    <div style={{width:'100%',height:'420px',background:'#31466e',display:'inline-block',color:'#ffffff',textAlign:'center'}}>
   <p style={{marginTop:'30px',fontSize:'45px',fontFamily:'poppins'}}><b>Languages</b></p> 
      <p style={{marginTop:'-35px',fontSize:'25px',fontFamily:'poppins'}}><b>Storyflics allows users to choose multiple languages across globe</b></p>
      <div>
      <p><img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/English.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Tamil.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Malayalam.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Kannada.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Telugu.png?raw=true"/></p>
      <p style={{marginTop:'40px'}}><img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/FRENCH.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Spanish.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Deutsch.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/French.png?raw=true"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img width="150px" src="https://github.com/vijay9655/Sample-img/blob/main/Korean.png?raw=true"/></p>
      </div>
    </div>
  )
}
  
export default Bodycomponent2