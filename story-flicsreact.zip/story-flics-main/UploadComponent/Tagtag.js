// import React, { useState } from 'react'
// import {Input, Tag} from 'antd'
// import styles from '../styles/Home.module.css'

// function Tagtag() {
//     const [stat,setStat] = useState({
//       tags:[],
//       inputVisible:'false',
//       inputValue:''
//     })

//    const inputTag=()=>{
//      setStat({inputVisible:'true'},input.focus())
//    }

//    const saveInputRef = (input) => {
//     input = input;
//   };
//   return (
//     <div>
//         <div>
//         <Tag  onClick={inputTag}>
//            Tag
//         </Tag>
//         </div>
//     </div>
//   )
// }

// export default Tagtag